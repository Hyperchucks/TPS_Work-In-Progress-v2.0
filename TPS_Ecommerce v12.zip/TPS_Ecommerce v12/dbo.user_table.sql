﻿CREATE TABLE [dbo].[Table]
(
	[ID] INT NOT NULL PRIMARY KEY, 
    [UserName] NCHAR(20) NULL, 
    [Email] NCHAR(50) NULL, 
    [Password] NCHAR(10) NULL, 
    [SecurityLevel] NCHAR(10) NULL
)
