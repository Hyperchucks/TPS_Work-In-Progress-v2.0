﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;

namespace CIS_TPS_Website
{
    public partial class ContractManager : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserID"] != null)
            {
                ADODB.Connection cn = new ADODB.Connection();
                ADODB.Recordset rs = new ADODB.Recordset();
                string cnStr;
                //Connection string.
                string DBDIR;
                DBDIR = "F:\\TPS_Ecommerce v12\\TPS.accdb";
                cnStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DBDIR;
                //Connection via Connection open Property.
                cn.Open(cnStr);
                rs.Open("candidate", cnStr, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, 2);

                do
                {
                    if (SessionManager.UserID == Convert.ToString(rs.Fields["user_ID"].Value))
                    {
                        LabelWelcome.Text = "Welcome " + rs.Fields["candidate_Fname"].Value + " " + rs.Fields["candidate_Lname"].Value;
                        break;
                    }
                    rs.MoveNext();
                } while (rs.EOF != true);
            }
            else
                Response.Redirect("Home.aspx");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session["New"] = null;
            Response.Redirect("Home.aspx");

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ADODB.Connection cn = new ADODB.Connection();
            ADODB.Recordset rs = new ADODB.Recordset();
            string cnStr;
            //Connection string.
            string DBDIR;
            DBDIR = "F:\\TPS_Ecommerce v12\\TPS.accdb";
            cnStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DBDIR;
            //Connection via Connection open Property.
            cn.Open(cnStr);
            rs.Open("requisition", cnStr, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, 2);

            do
            {
                
                

                    rs.Fields["requistion_Status"].Value = "@requistion_Status";
                    rs.Update();
                    rs.Close();
                    cn.Close();
                    break;
                

                rs.MoveNext();
            } while (rs.EOF != true);

            Response.Redirect("ContractManager.aspx");
            }
        
    }
}
