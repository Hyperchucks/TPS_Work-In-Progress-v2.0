﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//using System.Data.SqlClient; //addded for db
//using System.Configuration; //Added for db
//using System.Data.OleDb;
//using ADODB; //for db conn

namespace CIS_TPS_Website
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ADODB.Connection cn = new ADODB.Connection();
            ADODB.Recordset rs = new ADODB.Recordset();
            string user_SecurityLevel;
            string cnStr;
            //Connection string.
            string DBDIR;
            DBDIR = "F:\\TPS_Ecommerce v12\\TPS.accdb";
            cnStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DBDIR;
            //Connection via Connection open Property.
            cn.Open(cnStr);
            rs.Open("user_table", cnStr, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, 2);  //ADODB.CommandTypeEnum.adCmdTable = 2
            int userID;
            Boolean UserCheck;
            UserCheck = false;
            do
            {
                string test;
                string test2;
                test = rs.Fields["user_Logon"].Value;
                test2 = txtUserName.Text;
                if (test == test2)
                {
                    UserCheck = true;
                    break;
                }
                else
                {
                }
                rs.MoveNext();
            } while (rs.EOF != true);

            if (UserCheck == false)
            {
                rs.AddNew();
                rs.Fields["user_Logon"].Value = txtUserName.Text;
                rs.Fields["user_Password"].Value = txtPassword.Text;
                rs.Fields["user_SecurityLevel"].Value = DropDownSecurityLevel.Text;
                userID = rs.Fields["user_ID"].Value;
                rs.Update();
                SessionManager.UserID = userID.ToString();
                rs.Close();
                rs.Open("candidate", cnStr, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, 2);  //ADODB.CommandTypeEnum.adCmdTable = 2
                rs.AddNew();
                rs.Fields["user_ID"].Value = userID;
                rs.Update();
                rs.Close();


                cn.Close();
                Response.Redirect("Home.aspx");
              

            }
            else
            {
                //send error message to user
                rs.Close();
                cn.Close();
                Response.Write("Username already exists");
            }

          

        }
    }
}