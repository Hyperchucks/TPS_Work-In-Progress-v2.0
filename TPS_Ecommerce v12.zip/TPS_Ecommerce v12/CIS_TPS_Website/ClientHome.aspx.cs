﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CIS_TPS_Website
{
    public partial class ClientHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCreateContract_Click(object sender, EventArgs e)
        {
            Response.Redirect("CreateContract.aspx");
        }

        protected void btnViewStaff_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewAllStaff.aspx");

        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}