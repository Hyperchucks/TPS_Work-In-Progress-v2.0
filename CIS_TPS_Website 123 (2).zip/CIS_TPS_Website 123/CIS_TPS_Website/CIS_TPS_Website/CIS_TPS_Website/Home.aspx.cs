﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

namespace CIS_TPS_Website
{
    public partial class Home : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
          Console.Write(HttpRuntime.BinDirectory);
          
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {


            ADODB.Connection cn = new ADODB.Connection();
            ADODB.Recordset rs = new ADODB.Recordset();
            string cnStr;
            //Connection string.
           //// string BINDIR;
            
            ////BINDIR = HttpRuntime.BinDirectory;
           //// BINDIR = Left(BINDIR, (BINDIR.Length)-5);
            string DBDIR;
            DBDIR = "F:\\CIS_TPS_Website 123\\CIS_TPS_Website\\CIS_TPS_Website\\TPS.accdb";
           //// DBDIR = BINDIR + "TPS.accdb";
            cnStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DBDIR;
            //Connection via Connection open Property.
            cn.Open(cnStr);
            rs.Open("user_table", cnStr, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, 2);  //ADODB.CommandTypeEnum.adCmdTable = 2
            int userID;
            Boolean UserCheck;
            /// SELECT user_ID where user_logon =UserName.text.Text
            UserCheck = false;
            do
            {
                string userDatabase;
                string userTextField;
                string passwordDatabase;
                string passwordTextField;
                userDatabase = rs.Fields["user_Logon"].Value;
                userTextField = txtUserNameLogin.Text;
                passwordDatabase = rs.Fields["user_Password"].Value;
                passwordTextField = txtPasswordLogin.Text;
                if (userDatabase == userTextField)
                {

                    if (passwordDatabase == passwordTextField)
                    {
                        UserCheck = true;
                        SessionManager.UserID = Convert.ToString(rs.Fields["user_ID"].Value);
                        break;
                    }

                }
                else
                {
                }
                rs.MoveNext();
            } while (rs.EOF != true);

            if (UserCheck == true)
            {
                string userSecurityLevel;
                userSecurityLevel = rs.Fields["user_SecurityLevel"].Value;

                //passwordDatabase = rs.Fields["user_Password"].Value;
                //passwordTextField = txtPasswordLogin.Text;
                if (userSecurityLevel == "CM")
                {
                    Response.Redirect("ContractManager.aspx");

                }

                else if (userSecurityLevel == "CAN")
                {
                    

                    Response.Redirect("ViewResume.aspx");

                }

                else
                {
                    Response.Redirect("ClientHome.aspx");


                }
            }
            else
            {
                Response.Write("That is the wrong user name and password");
            }
            rs.Close();
            cn.Close();
            //

        }
    }
}