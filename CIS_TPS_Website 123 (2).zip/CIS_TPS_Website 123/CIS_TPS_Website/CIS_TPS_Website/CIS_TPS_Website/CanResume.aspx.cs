﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Net;
using System.Data;

namespace CIS_TPS_Website
{
    public partial class UpdateResume : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserID"] != null)
            {
                ADODB.Connection cn = new ADODB.Connection();
                ADODB.Recordset rs = new ADODB.Recordset();
                string cnStr;
                //Connection string.
                string DBDIR;
                DBDIR = "F:\\CIS_TPS_Website 123\\CIS_TPS_Website\\CIS_TPS_Website\\TPS.accdb";
                cnStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DBDIR;
                //Connection via Connection open Property.
                cn.Open(cnStr);
                rs.Open("candidate", cnStr, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, 2);

                do
                {
                    if (SessionManager.UserID == Convert.ToString(rs.Fields["user_ID"].Value))
                    {
                        LabelWelcome.Text = "Welcome " + rs.Fields["candidate_Fname"].Value + " " + rs.Fields["candidate_Lname"].Value;
                        rs.Close();
                        cn.Close();
                        break;
                        
                    }
                    rs.MoveNext();
                } while (rs.EOF != true);
            }
            else
            {
                Response.Redirect("Home.aspx");
                
            }
                
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        protected void Create_Click(object sender, EventArgs e)
        {
            if (pictureFileUpload.HasFile)
            {
                //save image into database
                string strPic1 = pictureFileUpload.FileName;
                pictureFileUpload.PostedFile.SaveAs(Server.MapPath(".") + "//Pictures//" + strPic1);
                string path = "~//Pictures//" + strPic1.ToString();




                if (resumeFileUpload.HasFile)
                {
                    //save document/images into database
                    string strRes1 = resumeFileUpload.FileName;
                    resumeFileUpload.PostedFile.SaveAs(Server.MapPath(".") + "//Resumes//" + strRes1);
                    string path1 = "~//Resumes//" + strRes1.ToString();

                    ADODB.Connection cn = new ADODB.Connection();
                    ADODB.Recordset rs = new ADODB.Recordset();
                    string cnStr;
                    //Connection string.
                    string DBDIR;
                    DBDIR = "F:\\CIS_TPS_Website 123\\CIS_TPS_Website\\CIS_TPS_Website\\TPS.accdb";
                    cnStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DBDIR;
                    //Connection via Connection open Property.
                    cn.Open(cnStr);
                    rs.Open("candidate", cnStr, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, 2);



                    do
                    {
                        if (SessionManager.UserID == Convert.ToString(rs.Fields["user_ID"].Value))
                        {

                            rs.Fields["candidate_Fname"].Value = txtFirstName.Text;
                            rs.Fields["candidate_Lname"].Value = lastNametxt.Text;
                            rs.Fields["candidate_City"].Value = citytxt.Text;
                            rs.Fields["candidate_State"].Value = statetxt.Text;
                            rs.Fields["candidate_Zip"].Value = zipCodetxt.Text;
                            rs.Fields["candidate_Email"].Value = emailtxt.Text;
                            rs.Fields["candidate_Phone"].Value = phonetxt.Text;
                            rs.Fields["candidate_Field"].Value = fieldtxt.Text;
                            rs.Fields["candidate_Ed"].Value = educationtxt.Text;
                            rs.Fields["candidate_Salary"].Value = salarytxt.Text;
                            rs.Fields["candidate_Location"].Value = locationtxt.Text;
                            //rs.Fields["candidate_Resume"].Value = pictureFileUpload.;
                            rs.Fields["candidate_Pic"].Value = path1;
                            //////TESTING BELOW
                            ////string imgName = pictureFileUpload.FileName;
                            ////string imgPath = "//Pictures//" + imgName;

                            ////int imgSize = pictureFileUpload.PostedFile.ContentLength;

                            ////if (pictureFileUpload.PostedFile != null && pictureFileUpload.PostedFile.FileName != "")
                            ////{
                            ////    if (pictureFileUpload.PostedFile.ContentLength > 102400)
                            ////    {
                            ////        Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Alert", "alert('File is too big.')", true);
                            ////    }
                            ////    else
                            ////    {
                            ////        pictureFileUpload.SaveAs(Server.MapPath(imgPath));
                            ////        pictureFileUpload.PostedFile.SaveAs(Server.MapPath(".") + "//Pictures//" + imgName);
                            ////        ADODB.Connection con = new ADODB.Connection();
                            ////        // Image1.ImageUrl = "~/" + imgPath;
                            ////        Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Alert", "alert('Image saved!')", true);
                            ////    }
                            ////}
                            ////rs.Fields["candidate_Pic"].Value = pictureFileUpload.Controls;
                            rs.Update();
                            rs.Close();
                            cn.Close();
                            break;
                        }
                        rs.MoveNext();
                    } while (rs.EOF != true);

                    Response.Redirect("ViewResume.aspx");
                }
            }
        }


    
        
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
                    
            ADODB.Connection cn = new ADODB.Connection();
            ADODB.Recordset rs = new ADODB.Recordset();
            string cnStr;
            //Connection string.
            string DBDIR;
            DBDIR = "F:\\CIS_TPS_Website 123\\CIS_TPS_Website\\CIS_TPS_Website\\TPS.accdb";
            cnStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DBDIR;
            //Connection via Connection open Property.
            cn.Open(cnStr);
            rs.Open("candidate", cnStr, ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockOptimistic, 2);
            //command.Connection = connect;
            //command.CommandType = CommandType.Text;

            do
            {
                if (SessionManager.UserID == Convert.ToString(rs.Fields["user_ID"].Value))
                {

                    rs.Fields["candidate_Fname"].Value = txtFirstName.Text;
                    rs.Fields["candidate_Lname"].Value = lastNametxt.Text;
                    rs.Fields["candidate_City"].Value = citytxt.Text;
                    rs.Fields["candidate_State"].Value = statetxt.Text;
                    rs.Fields["candidate_Zip"].Value = zipCodetxt.Text;
                    rs.Fields["candidate_Email"].Value = emailtxt.Text;
                    rs.Fields["candidate_Phone"].Value = phonetxt.Text;
                    rs.Fields["candidate_Field"].Value = fieldtxt.Text;
                    rs.Fields["candidate_Ed"].Value = educationtxt.Text;
                    rs.Fields["candidate_Salary"].Value = salarytxt.Text;
                    rs.Fields["candidate_Location"].Value = locationtxt.Text;
                    //  rs.Fields["candidate_Resume"].Value = txtFirstName.Text;
                    // rs.Fields["candidate_Pic"].Value = txtFirstName.Text;
                    rs.Update();
                    rs.Close();
                    cn.Close();
                    break;
                }
                rs.MoveNext();
            } while (rs.EOF != true);

            Response.Redirect("ViewResume.aspx");
           
        }
    }
}